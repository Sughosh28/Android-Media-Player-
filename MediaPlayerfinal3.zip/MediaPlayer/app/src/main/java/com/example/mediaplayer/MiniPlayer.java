package com.example.mediaplayer;

import static com.example.mediaplayer.player.mMediaPlayer;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MiniPlayer extends RelativeLayout {
    private Button playButton;
    private TextView songTitleTextView;

    private boolean isPlaying = false;
    public MiniPlayer(Context context) {
        super(context);
        init();
    }
    public MiniPlayer(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }
    public MiniPlayer(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }
    private void init() {
        LayoutInflater.from(getContext()).inflate(R.layout.twoo, this, true);
        playButton = findViewById(R.id.play_button);
        songTitleTextView = findViewById(R.id.song_title_textview);
        playButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                togglePlayback();
            }
        });
    }
    private void togglePlayback() {
        if (isPlaying) {
            pausePlayback();
        } else {
            startPlayback();
        }
    }
    void startPlayback() {
        mMediaPlayer.start();
        isPlaying = true;
        playButton.setText("II");
    }

    void pausePlayback() {
        mMediaPlayer.pause();
        isPlaying = false;
        playButton.setText("Play");
    }
        public void setSongTitle(String songTitle) {

            songTitleTextView.setText(songTitle);
        }
    }


