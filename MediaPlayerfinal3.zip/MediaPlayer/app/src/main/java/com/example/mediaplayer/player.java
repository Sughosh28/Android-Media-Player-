package com.example.mediaplayer;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;


public class player extends AppCompatActivity {
    Bundle songExtraData;
    private int playBackPosition;
    private static final int NOTIFICATION_ID = 1001;
    private static final String CHANNEL_ID = "your_channel_id";

    ImageView loop, img;
    boolean isQueuePlaying = true;
    private ArrayList<File> songQueue = new ArrayList<>();
    private boolean isSeeking = false;
    TextView twoo, onee;
    Button prev, play, next;
    ImageView shuffleButton;
    boolean fabClicked;
    int position;
    SeekBar mSeekBarTime;
    private boolean shuffle = false;
    static MediaPlayer mMediaPlayer;
    TextView songName;
    boolean isShuffleEnabled = false;
    private ObjectAnimator rotationAnimator;
    ArrayList<File> musicList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);
        prev = findViewById(R.id.prev);
        loop = findViewById(R.id.loop);
        ArrayList<String> songPaths = getIntent().getStringArrayListExtra("songQueue");
        if (songPaths != null) {
            for (String path : songPaths) {
                File file = new File(path);
                songQueue.add(file);
            }
        }
        img = findViewById(R.id.img);
        img.setRotation(0);
        rotationAnimator = ObjectAnimator.ofFloat(img, "rotation", 0f, 360f);
        rotationAnimator.setDuration(4000);
        rotationAnimator.setRepeatCount(ObjectAnimator.INFINITE);
        rotationAnimator.setInterpolator(new LinearInterpolator());
        startRotation();
        loop.setOnClickListener(view -> {
            if (mMediaPlayer != null) {
                boolean isLoopingEnabled = mMediaPlayer.isLooping();
                mMediaPlayer.setLooping(!isLoopingEnabled);
                updateLoopButtonUI(!isLoopingEnabled);
            }
        });
        onee = findViewById(R.id.onee);
        twoo = findViewById(R.id.twoo);
        play = findViewById(R.id.play);
        shuffleButton = findViewById(R.id.shufflebtn);
        shuffleButton.setOnClickListener(view -> {
            toggleShuffle();
            if (isShuffleEnabled = !isShuffleEnabled) {
                toggleShuffleBlack();
            } else {
                toggleSuffleWhite();
            }
        });
        next = findViewById(R.id.next);
        mSeekBarTime = findViewById(R.id.seek);
        songName = findViewById(R.id.namee);
        if (mMediaPlayer != null) {
            mMediaPlayer.stop();
        }
        Intent intent = getIntent();
        songExtraData = intent.getExtras();
        if (songExtraData != null) {
            musicList = (ArrayList<File>) songExtraData.get("songslist");

            position = songExtraData.getInt("position", 0);
            initialiseMusicPlayer(position);
        }
        play.setOnClickListener(view -> play());
        next.setOnClickListener(view -> {
            if (shuffle) {
                Random random = new Random();
                position = random.nextInt(musicList.size());
            } else if (position < musicList.size() - 1) {
                position++;
                Intent iintent = new Intent();
                iintent.setAction("com.example.mediaplayer.ACTION_INCREMENT_POSITION");
                sendBroadcast(iintent);
            } else {
                position = 0;
            }
            initialiseMusicPlayer(position);
            boolean isLoopingEnabled = mMediaPlayer != null && mMediaPlayer.isLooping();
            updateLoopButtonUI(isLoopingEnabled);
        });

        prev.setOnClickListener(view -> {
            if (position <= 0) {
                position = musicList.size();
                Intent iintent3 = new Intent();
                iintent3.setAction("com.example.mediaplayer.ACTION_DECREMENT_POSITION");
                sendBroadcast(iintent3);
            } else {
                position--;
                Intent iintent4 = new Intent();
                iintent4.setAction("com.example.mediaplayer.ACTION_DECREMENT_POSITION");
                sendBroadcast(iintent4);
            }
            initialiseMusicPlayer(position);
        });
    }
    private void initialiseMusicPlayer(int position) {
        if (mMediaPlayer != null && mMediaPlayer.isPlaying()) {
            mMediaPlayer.reset();
        } else {
            mMediaPlayer = new MediaPlayer();
        }
        if (musicList != null && position >= 0 && position < musicList.size()) {
            File song = musicList.get(position);
            String name = song.getName();
            songName.setText(name);
            Uri uri = Uri.parse(musicList.get(position).toString());
            mMediaPlayer = MediaPlayer.create(this, uri);
            mMediaPlayer.setOnPreparedListener(mediaPlayer -> {
                mSeekBarTime.setMax(mMediaPlayer.getDuration());
                play.setText("II");
                twoo.setText(getTimeString(mMediaPlayer.getDuration()));
                updateSeekBar();
                if (!fabClicked) {
                    mMediaPlayer.start();
                } else {
                    mMediaPlayer.seekTo(playBackPosition);
                    mMediaPlayer.start();
                }
                // mMediaPlayer.start();
            });
            mMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    if (isQueuePlaying) {
                        Intent intent = new Intent();
                        intent.setAction("com.example.mediaplayer.ACTION_INCREMENT_POSITION");
                        sendBroadcast(intent);
                        playNextSong();
                    }
                }
            });

            mSeekBarTime.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

                    if (b) {
                        mSeekBarTime.setProgress(i);
                        mMediaPlayer.seekTo(i);
                    }
                    onee.setText(getTimeString(i));
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                    isSeeking = true;
                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                    isSeeking = false;
                }
            });
            new Thread(() -> {
                while (mMediaPlayer != null) {
                    try {
                        if (mMediaPlayer.isPlaying()) {
                            Message mes = new Message();
                            mes.what = mMediaPlayer.getCurrentPosition();
                            handler.sendMessage(mes);
                            Thread.sleep(1000);
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }
    }

    @SuppressLint("HandlerLeak")
    private final Handler handler = new Handler(Looper.myLooper()) {
        @Override
        public void handleMessage(Message msg) {
            mSeekBarTime.setProgress(msg.what);
        }
    };

    private void play() {
        if (mMediaPlayer != null) {
            if (mMediaPlayer.isPlaying()) {
                mMediaPlayer.pause();
                playBackPosition = mMediaPlayer.getCurrentPosition();
                stopRotation();
                play.setText("Play");
            } else {
                if (mMediaPlayer.getCurrentPosition() == mMediaPlayer.getDuration()) {
                    // If the song has reached the end, reset to the stored position
                    mMediaPlayer.seekTo(playBackPosition);
                }
                mMediaPlayer.start();
                play.setText("II");
                startRotation();
            }
        }
    }

    private void updateSeekBar() {
        mSeekBarTime.setProgress(mMediaPlayer.getCurrentPosition());
        onee.setText(getTimeString(mMediaPlayer.getCurrentPosition()));
        if (mMediaPlayer.isPlaying() && !isSeeking) {
            Runnable runnable = new Runnable() {

                @Override
                public void run() {
                    updateSeekBar();
                }
            };
            mSeekBarTime.postDelayed(runnable, 1000);
        }
    }

    private String getTimeString(int millis) {
        int seconds = millis / 1000;
        int minutes = seconds / 60;
        seconds = seconds % 60;
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
    }

    private void toggleShuffle() {
        shuffle = !shuffle;
        ImageView suffleButton = findViewById(R.id.shufflebtn);
        shuffleButton.setActivated(shuffle);
        Toast.makeText(this, "Shuffle " + (shuffle ? "enabled" : "disabled"), Toast.LENGTH_SHORT).show();
    }

    private void toggleShuffleBlack() {
        if (isShuffleEnabled) {
            shuffleButton.setImageResource(R.drawable.shuffle2);
        }
    }

    private void toggleSuffleWhite() {
        if (!isShuffleEnabled) {
            shuffleButton.setImageResource(R.drawable.shuffle);
        }
    }

    private void playNextSong() {
        if (!songQueue.isEmpty()) {
            File nextSong = songQueue.remove(0);
            int nextSongPosition = musicList.indexOf(nextSong);
            initialiseMusicPlayer(nextSongPosition);
        } else if (shuffle) {
            Random random = new Random();
            int randomPosition = random.nextInt(musicList.size());
            initialiseMusicPlayer(randomPosition);

        } else {
            if (position < musicList.size() - 1) {
                position++;
            } else {
                position = 0;
            }
            initialiseMusicPlayer(position);

        }
        play(); // Start playing the next song
    }

    private void updateLoopButtonUI(boolean isLoopingEnabled) {
        if (isLoopingEnabled) {
            loop.setImageResource(R.drawable.img_6);
            Toast.makeText(this, "Loop mode enabled", Toast.LENGTH_SHORT).show();
        } else {
            loop.setImageResource(R.drawable.img_7);

        }
    }

    private void startRotation() {
        if (!rotationAnimator.isRunning()) {
            rotationAnimator.start();
        }
    }

    private void stopRotation() {
        if (rotationAnimator.isRunning()) {
            rotationAnimator.end();
        }
    }

}

