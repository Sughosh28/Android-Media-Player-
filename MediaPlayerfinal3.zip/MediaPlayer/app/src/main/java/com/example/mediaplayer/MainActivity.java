package com.example.mediaplayer;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.io.File;
import java.util.ArrayList;
public class MainActivity extends AppCompatActivity implements View.OnCreateContextMenuListener {
    ListView listview;
    private int currentlyPlayingPosition = -1;
    private static final int PERMISSION_REQUEST_CODE = 1;
    ArrayAdapter<String> musicarrary;
    String[] songs;
    ArrayList<File> musics;
    private MiniPlayer miniPlayerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listview = findViewById(R.id.lsv);
        FrameLayout miniPlayerContainer = findViewById(R.id.mini_player_container);
        miniPlayerView = new MiniPlayer(this);
        miniPlayerContainer.addView(miniPlayerView);
        String songName = getSongName(currentlyPlayingPosition);
        miniPlayerView.setSongTitle(songName);
        IntentFilter intentFilter = new IntentFilter("com.example.mediaplayer.ACTION_INCREMENT_POSITION");
        registerReceiver(incrementPositionReceiver, intentFilter);
        IntentFilter intentFilter1 = new IntentFilter("com.example.mediaplayer.ACTION_INCREMENT_POSITION");
        registerReceiver(incrementPositionReceiver, intentFilter1);
        IntentFilter decrementIntentFilter = new IntentFilter("com.example.mediaplayer.ACTION_DECREMENT_POSITION");
        registerReceiver(decrementPositionReceiver, decrementIntentFilter);
        IntentFilter decrementIntentFilter2 = new IntentFilter("com.example.mediaplayer.ACTION_DECREMENT_POSITION");
        registerReceiver(decrementPositionReceiver, decrementIntentFilter2);



        Dexter.withContext(this).withPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE).withListener(new PermissionListener() {
            @Override
            public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                musics = findMusicFiles(Environment.getExternalStorageDirectory());
                songs = new String[musics.size()];
                for (int i = 0; i < musics.size(); i++) {
                    songs[i] = musics.get(i).getName();
                }
                musicarrary = new ArrayAdapter<String>(getApplicationContext(), R.layout.list_item, songs) {

                    @NonNull
                    @Override
                    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                        View view = super.getView(position, convertView, parent);
                        TextView songTitleTextView = view.findViewById(R.id.song_title_text_view);
                        if (position == currentlyPlayingPosition) {
                            songTitleTextView.setTextColor(Color.MAGENTA);
                        } else {
                            songTitleTextView.setTextColor(Color.BLACK);
                        }
                        return view;
                    }
                };
                listview.setAdapter(musicarrary);
                listview.setOnItemClickListener((adapterView, view, i, l) -> {
                    currentlyPlayingPosition = i;
                    musicarrary.notifyDataSetChanged();
                    startActivity(new Intent(MainActivity.this, player.class)
                            .putExtra("songslist", musics)
                            .putExtra("position", i));
                });
                listview.setOnItemLongClickListener((adapterView, view, i, l) -> {
                    final int position = i;

                    AlertDialog.Builder builder= new AlertDialog.Builder(MainActivity.this);
                    //.setTitle("Options")
                    //.setMessage("What action would you like to perform")
                    builder .setTitle("Options");
                    String[] options = {"Set as Ringtone", "Delete ", "Share"};
                    builder  .setItems(options, (dialog, which) -> {
                        // Handle the selected option
                        switch (which) {
                            case 0:
                                setRingtone(position);
                                break;
                            case 1:
                                deleteFile( position);
                                break;
                            case 2:
                                File musicFile = musics.get(position);
                                String songName1 = musicFile.getName();
                                shareSong(songName1);
                                break;
                        }
                    });
                    builder.show();

                    return true; // Return true to indicate that the event is consumed

                });
            }
            @Override
            public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {

            }

            @Override
            public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
                permissionToken.continuePermissionRequest();
            }
        }).check();

    }
    private ArrayList<File> findMusicFiles(File file) {
        ArrayList<File> musicobject = new ArrayList<>();
        File[] files = file.listFiles();
        if (files != null) {
            for (File currentFiles : files) {
                if (currentFiles.isDirectory() && !currentFiles.isHidden()) {
                    musicobject.addAll(findMusicFiles(currentFiles));
                } else {
                    if (currentFiles.getName().endsWith(".mp3") || currentFiles.getName().endsWith(".mp4a") || currentFiles.getName().endsWith(".wav")) {
                        musicobject.add(currentFiles);
                    }
                }
            }
        }
        return musicobject;
    }

    private void setRingtone(int position) {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
            return;
        }

        String selectedPath = String.valueOf(musics.get(position));
        Uri audioUri = Uri.parse(selectedPath);

        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DATA, selectedPath);
        values.put(MediaStore.MediaColumns.TITLE, "Custom Ringtone");
        values.put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp3");

        getContentResolver().delete(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, MediaStore.MediaColumns.DATA + "=?", new String[]{selectedPath});

        Uri newUri = getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values);
        RingtoneManager.setActualDefaultRingtoneUri(
                MainActivity.this, RingtoneManager.TYPE_RINGTONE, newUri);

        Toast.makeText(MainActivity.this, "Ringtone set successfully", Toast.LENGTH_SHORT).show();
    }
    private void deleteFile(int position) {
        String filePath = musics.get(position).getAbsolutePath();
        File fileToDelete = new File(filePath);

        if (fileToDelete.delete()) {
            // File deleted successfully
            musics.remove(position);
            musicarrary.notifyDataSetChanged();
            Toast.makeText(MainActivity.this, "File deleted", Toast.LENGTH_SHORT).show();
        } else {
            // Failed to delete the file
            Toast.makeText(MainActivity.this, "Failed to delete the file", Toast.LENGTH_SHORT).show();
        }
    }
    private BroadcastReceiver incrementPositionReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null && intent.getAction() != null && intent.getAction().equals("com.example.mediaplayer.ACTION_INCREMENT_POSITION")) {
                currentlyPlayingPosition++;
                musicarrary.notifyDataSetChanged();
            }
        }
    };
    private BroadcastReceiver decrementPositionReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null && intent.getAction() != null && intent.getAction().equals("com.example.mediaplayer.ACTION_DECREMENT_POSITION")) {
                currentlyPlayingPosition--;
                musicarrary.notifyDataSetChanged();
            }
        }
    };
    private void shareSong(String songName) {
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, "Check out this song: " + songName);

        String title = "Share Song";
        startActivity(Intent.createChooser(shareIntent, title));
    }
    private String getSongName(int position) {
        if (musics != null && position >= 0 && position < musics.size()) {
            File musicFile = musics.get(position);
            return musicFile.getName();
        }
        return "";
    }
        }











